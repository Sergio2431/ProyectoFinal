<?php

$nif=$_POST['nif'];
$contrasenya=$_POST['contrasenya'];


echo("NIF: ".$nif."CONTRASEÑA: ".$contrasenya);
?>
