<?php

$nombre=$_POST['Nombre'];
$horas=$_POST['Horas'];
$precio=$_POST['Precio'];
$descripcion=$_POST['Descripcion'];


echo("NOMBRE: ".$nombre."HORAS: ".$horas."PRECIO: ".$precio."DESCRIPCION: ".$descripcion);
?>
